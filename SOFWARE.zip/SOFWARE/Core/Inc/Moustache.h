

#ifndef MOUSTACHE_H
#define MOUSTACHE_H

#include "gpio.h"
// Prototypes des fonctions
void Moustache_Init(void);
void Moustache_HandleInterrupt(uint16_t GPIO_Pin);

#endif // MOUSTACHE_H
